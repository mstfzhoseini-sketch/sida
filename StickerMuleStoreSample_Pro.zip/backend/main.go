package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"

	"github.com/99designs/gqlgen/graphql/handler"
	"github.com/99designs/gqlgen/graphql/playground"
	"github.com/go-redis/redis/v8"
	"github.com/jackc/pgx/v5/pgxpool"
)

var ctx = context.Background()

func main() {
	// Connect Postgres
	dbURL := os.Getenv("DATABASE_URL")
	pool, err := pgxpool.New(ctx, dbURL)
	if err != nil {
		log.Fatal("Unable to connect to database:", err)
	}
	defer pool.Close()

	// Redis cache
	rdb := redis.NewClient(&redis.Options{
		Addr: "redis:6379",
	})
	defer rdb.Close()

	val, err := rdb.Get(ctx, "example").Result()
	if err != nil {
		log.Println("Redis cache empty, setting value")
		rdb.Set(ctx, "example", "Redis is working!", 0)
	} else {
		log.Println("Redis test value:", val)
	}

	// GraphQL server placeholder (can integrate gqlgen resolvers)
	http.Handle("/", playground.Handler("GraphQL Playground", "/query"))
	http.HandleFunc("/query", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`{"data":{"products":[{"id":"1","name":"Sticker A","price":10},{"id":"2","name":"Sticker B","price":15}]}}`))
	})

	port := "8080"
	fmt.Println("Server running on http://localhost:" + port)
	log.Fatal(http.ListenAndServe(":"+port, nil))
}
