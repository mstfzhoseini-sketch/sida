import React, { useEffect, useState } from "react";
import { View, Text, FlatList, StyleSheet, Button, TextInput } from "react-native";

type Product = {
  id: string;
  name: string;
  price: number;
};

export default function App() {
  const [products, setProducts] = useState<Product[]>([]);
  const [newName, setNewName] = useState("");
  const [newPrice, setNewPrice] = useState("");

  const fetchProducts = () => {
    fetch("http://localhost:8080/query", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ query: "{ products { id name price } }" }),
    })
      .then((res) => res.json())
      .then((data) => setProducts(data.data.products))
      .catch((err) => console.error(err));
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const addProduct = () => {
    // Mock adding product
    setProducts([...products, { id: Date.now().toString(), name: newName, price: parseInt(newPrice) }]);
    setNewName(""); setNewPrice("");
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Sticker Mule Store Pro Sample</Text>
      <FlatList
        data={products}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <Text style={styles.item}>{item.name} - ${item.price}</Text>
        )}
      />
      <TextInput placeholder="Product Name" value={newName} onChangeText={setNewName} style={styles.input} />
      <TextInput placeholder="Product Price" value={newPrice} onChangeText={setNewPrice} style={styles.input} keyboardType="numeric"/>
      <Button title="Add Product" onPress={addProduct} />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, marginTop: 50 },
  title: { fontSize: 20, fontWeight: "bold", marginBottom: 20 },
  item: { fontSize: 16, marginBottom: 10 },
  input: { borderWidth: 1, borderColor: "#ccc", padding: 10, marginBottom: 10 }
});
