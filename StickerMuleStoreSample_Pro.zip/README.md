# StickerMuleStoreSample Pro

A professional Full Stack sample project demonstrating Go + GraphQL + Postgres + Redis backend and React Native frontend (Expo + TypeScript).

## Features
- GraphQL API with CRUD operations (scaffolded)
- Postgres database connection
- Redis caching for performance
- React Native frontend with list & add product functionality
- TypeScript for type safety
- Docker Compose for full environment setup

## Tech Stack
- Backend: Go, GraphQL, Postgres, Redis
- Frontend: React Native, Expo, TypeScript

## Run with Docker
1. Install Docker and Docker Compose
2. Run `docker-compose up --build`
3. Backend GraphQL playground: http://localhost:8080/

## Run Frontend
1. Navigate to `frontend/`
2. `npm install`
3. `expo start`
